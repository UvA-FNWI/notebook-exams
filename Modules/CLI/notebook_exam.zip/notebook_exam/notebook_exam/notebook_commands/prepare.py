import click
import json

import json
import sys
import os
from subprocess import call
from shutil import copyfile

from xml.etree import ElementTree as ET
import xml
from slugify import slugify

from colorama import Fore, Back, Style

@click.command('student-notebook')
@click.argument('notebook_file')
def student_notebook(notebook_file):
    '''Creates a student version of a notebook.'''
    
    if not os.path.exists(notebook_file):
    	print Fore.RED + 'The notebook file does not exist.' + Style.RESET_ALL
    	exit()
    
    def check_and_create(folder):
    	if not os.path.exists(folder):
    		os.makedirs(folder)
    		
    def execute(c):
        call(c.split())
    
    in_nb = notebook_file
    nb_name = os.path.splitext(in_nb)[0]
    
    out_nb = nb_name +'/Student/'+ os.path.basename(in_nb)
    
    out_questions = nb_name +'/Student/questions.json'
    out_questions_answers = nb_name +'/Teacher/answer-model.json'
    
    check_and_create(nb_name)
    check_and_create(os.path.dirname(out_nb))
    check_and_create(os.path.dirname(out_questions))
    check_and_create(os.path.dirname(out_questions_answers))
    
    copyfile(in_nb, nb_name +'/Teacher/'+ nb_name +'.template.ipynb')
    
    data = json.load(open(in_nb))
    
    questions = []
    questions_with_answers = []
    
    new_cells = []
    question_number = 0
    
    currentMarkdown = None
    
    for cell in data['cells']:
    	if cell['cell_type'] == 'markdown':
    		for l in cell['source']:
    			el = None
    
    			try:
    				el = ET.fromstring(l)
    			except xml.etree.ElementTree.ParseError:
    				if not currentMarkdown:
    					currentMarkdown = []
    
    				currentMarkdown.append(l)
    
    			if el is not None and el.tag == 'answer':
    				#print ET.tostring(el)
    				if currentMarkdown:
    					new_cells.append({
    					   "cell_type": "markdown",
    					   "metadata": {},
    					   "source": currentMarkdown
    					},)
    
    					currentMarkdown = None
    
    				qid = el.attrib['id']
    
    				q = {
    					'id': qid,
    					'properties': el.attrib
    				}
    
    				questions.append(q)
    
    				if el.text:
    					q = q.copy()
    					q['answer-spec'] = el.text
    
    				questions_with_answers.append(q)
    
    				new_cells.append({
    					"cell_type": "code",
    					"execution_count": None,
    					"metadata": {
    						"collapsed": False
    					},
    					"outputs": [],
    					"source": ['questions.ask("%s")' % q['id']]
    				})
    
    	if currentMarkdown:
    		new_cells.append({
    		   "cell_type": "markdown",
    		   "metadata": {},
    		   "source": currentMarkdown
    		},)
    
    		currentMarkdown = None
    
    	if cell['cell_type'] == 'code':
    		cell['execution_count'] = None
    		cell['outputs'] = []
    
    		new_cells.append(cell)
    
    data['cells'] = new_cells
    
    json.dump(data, open(out_nb, 'w'))
    
    json.dump(questions, open(out_questions, 'w'))
    json.dump(questions_with_answers, open(out_questions_answers, 'w'))
    
    execute('zip -q -r %s/%s.zip %s/Student' % (nb_name, nb_name, nb_name))
    
    print
    print(Fore.GREEN + ('Notebook "%s" has been processed.' % in_nb) + Style.RESET_ALL)
    print('The following directory structure has been created:')
    print
    print('-- %s/' % nb_name)
    print('--- Student/\t\t\t\t(contains student version and question definitions file)')
    print('--- Teacher/\t\t\t\t(contains the original template and an answer model file)')
    print('--- %s.zip\t(a zip file that can be imported (see notebook-exam setup exam --help)' % nb_name)
    print